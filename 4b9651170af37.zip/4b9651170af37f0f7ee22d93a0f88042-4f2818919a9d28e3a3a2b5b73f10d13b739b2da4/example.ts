import { CronController } from 'path/to/cron-controller';

const controller = new CronController()
	.cron('0 * * * *', () => {
		console.log('Running hourly tasks...');
	})
	.cron('* * * * *', () => {
		console.log('Running tasks every minute...');
	});

export default {
	scheduled: controller.scheduled,
} satisfies ExportedHandler<Env>;
