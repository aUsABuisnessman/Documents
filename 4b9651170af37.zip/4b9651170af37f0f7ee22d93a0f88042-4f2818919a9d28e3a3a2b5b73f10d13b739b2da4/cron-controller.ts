type ScheduleHandler<E> = (
	context: ExecutionContext & {
		controller: ScheduledController;
		env: E;
	},
) => void | Promise<void>;

export class CronController<E = Env> {
	private _jobs: Array<{
		handler: ScheduleHandler<E>;
		schedule: string;
	}> = [];

	cron = (schedule: string, handler: ScheduleHandler<E>): this => {
		this._jobs.push({ handler, schedule });
		return this;
	};

	scheduled = async (
		controller: ScheduledController,
		env: E,
		ctx: ExecutionContext,
	): Promise<void> => {
		const selectedJob = this._jobs.find((job) => job.schedule === controller.cron);
		if (!selectedJob)
			return console.warn(`No cron job found for schedule "${controller.cron}"`);

		await selectedJob.handler(
			Object.assign(
				{},
				{
					controller,
					env,
				},
				ctx,
			),
		);
	};
}
